import React from "react"

function Profil() {
  return (
    <div className="profil mb5">
      <h2>Profil</h2>
      <p>
      Ayant récemment obtenu mon diplôme national d'art en images animées, je suis actuellement à la recherche d'un emploi dans le domaine de la 2D/3D afin de mettre mon expérience au service de votre entreprise.
      </p>
    </div>
  )
}

export default Profil
