export const dataExperiences = [
  {
    id: 2,
    title: "Animatrice d'un stand informatique",
    date: "Juin 2022",
    location: "Amiens, France",
    text: `Tenue d'un stand interactif en équipe Festival de la Bande Dessinée Amiens - Initiation d'un logiciel 3D aux visiteurs.`,
    missions: [
      {
        id: 1,
        title: "mission 1",
      },
      {
        id: 2,
        title: "mission 1",
      },
      {
        id: 3,
        title: "mission 1",
      },
    ]
  },
  {
    id: 1,
    title: "Conseillère de vente arts",
    date: "Décembre 2016",
    location: "Cultura Compiègne, France",
    text: `Stage en commerce conseillère de vente arts, papeterie et loisirs créatifs.`,
    missions: [
      {
        id: 1,
        title: "mission 1",
      },
      {
        id: 2,
        title: "mission 1",
      },
      {
        id: 3,
        title: "mission 1",
      },
    ],
  }
  
]
export default dataExperiences
